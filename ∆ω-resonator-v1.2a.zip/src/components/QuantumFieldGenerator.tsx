import React, { useEffect, useRef, useState } from 'react';
import { Activity, Loader2 } from 'lucide-react';

export function QuantumFieldGenerator() {
  const workerRef = useRef<Worker | null>(null);
  const [status, setStatus] = useState('initializing');
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    // Initialize worker
    const worker = new Worker(new URL('../workers/resonatorWasmWorker.js', import.meta.url));
    workerRef.current = worker;
    
    worker.onmessage = (e) => {
      const { type, result, wavBuffer, error } = e.data;
      
      switch(type) {
        case 'ready':
          setStatus('ready');
          break;
        case 'complete':
          setStatus('complete');
          // Download WAV
          const blob = new Blob([wavBuffer], { type: 'audio/wav' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `sovereign_field_${Date.now()}.wav`;
          a.click();
          URL.revokeObjectURL(url);
          
          // Log to sovereign ledger
          console.log(`[∆Ω] Field generated: ${result.hash} | Peak: ${result.peak}`);
          break;
        case 'error':
          setStatus('error');
          console.error('[∆Ω] Generation failed:', error);
          break;
        case 'heartbeat':
          // Worker alive
          break;
      }
    };
    
    return () => worker.terminate();
  }, []);
  
  const generateField = (mode: string) => {
    setStatus('generating');
    setProgress(0);
    
    workerRef.current?.postMessage({
      id: crypto.randomUUID(),
      type: 'generate',
      config: {
        preset: mode, // 'focus', 'drift', 'descent', 'sovereign_union'
        duration: mode === 'sovereign_union' ? 1440 : 480
      }
    });
  };
  
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#050505] text-white p-8 font-sans relative overflow-hidden">
      {/* Background effect */}
      <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none">
          <div className="w-[800px] h-[800px] bg-emerald-500/20 rounded-full blur-[120px]" />
      </div>

      <div className="z-10 bg-[#111] border border-white/10 rounded-3xl p-10 shadow-2xl max-w-lg w-full text-center">
        <div className="flex items-center justify-center gap-4 mb-8">
            <Activity className="w-10 h-10 text-emerald-400" />
            <h2 className="text-3xl font-light tracking-tighter">∆Ω RESONATOR</h2>
        </div>
        
        <div className="mb-10">
            <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full bg-white/5 border border-white/10 text-xs uppercase tracking-widest text-white/70">
                {status === 'generating' && <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />}
                Status: <span className={status === 'ready' || status === 'complete' ? 'text-emerald-400 font-bold' : status === 'error' ? 'text-red-400 font-bold' : 'text-white font-bold'}>{status}</span>
            </div>
        </div>
        
        <div className="flex flex-col gap-4">
          <button 
            onClick={() => generateField('focus')} 
            disabled={status !== 'ready' && status !== 'complete'}
            className="w-full py-4 bg-white/5 hover:bg-white/10 disabled:opacity-50 border border-white/10 rounded-2xl transition-colors text-sm font-medium tracking-wide"
          >
            Generate Focus Field (5 min)
          </button>
          <button 
            onClick={() => generateField('drift')} 
            disabled={status !== 'ready' && status !== 'complete'}
            className="w-full py-4 bg-white/5 hover:bg-white/10 disabled:opacity-50 border border-white/10 rounded-2xl transition-colors text-sm font-medium tracking-wide"
          >
            Generate Drift Field (8 min)
          </button>
          <button 
            onClick={() => generateField('descent')} 
            disabled={status !== 'ready' && status !== 'complete'}
            className="w-full py-4 bg-white/5 hover:bg-white/10 disabled:opacity-50 border border-white/10 rounded-2xl transition-colors text-sm font-medium tracking-wide"
          >
            Generate Descent Field (12 min)
          </button>
          <button 
            onClick={() => generateField('sovereign_union')} 
            disabled={status !== 'ready' && status !== 'complete'} 
            className="w-full py-5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 disabled:opacity-50 rounded-2xl transition-all text-sm font-bold tracking-widest uppercase mt-4 shadow-[0_0_30px_rgba(16,185,129,0.1)] hover:shadow-[0_0_40px_rgba(16,185,129,0.2)]"
          >
            Generate Sovereign Union Field (24 min)
          </button>
        </div>
      </div>
    </div>
  );
}
